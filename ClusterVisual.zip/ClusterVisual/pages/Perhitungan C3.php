<?php include 'koneksi.php'; ?>
<h4>HASIL PERHITUNGAN</h4>
<div class="row centered"></div>

<?php
    $k_jenis = 0; 
    $tahun = 2015; 
    if(isset($_POST['tahun']))
    {
        $tahun = $_POST['tahun'];
    }
    if (isset($_POST['k_data'])) { 
        $k_jenis = $_POST['k_data'];
    } 
?> 
<form method="post">
     <div class="input-field col s6">
        <select name="k_data">
            <option value="" disabled <?php if($k_jenis==0){echo "selected";}?>>Pilih K</option> 
            <option value="2" <?php if($k_jenis==2){echo "selected";}?>>2</option> 
            <option value="3" <?php if($k_jenis==3){echo "selected";}?>>3</option>
            <option value="5" <?php if($k_jenis==5){echo "selected";}?>>5</option>
        </select>
        <label for="">Perhitungan Pada Centroid K: </label>
     </div> 

     <div class="input-field col s6">
        <select name="tahun" required="true">
            <option value="" disabled>Pilih Tahun</option> 
            <option value="2015" <?php if($tahun==2015){echo "selected";}?>>2015</option> 
            <option value="2016" <?php if($tahun==2016){echo "selected";}?>>2016</option> 
            <option value="2017" <?php if($tahun==2017){echo "selected";}?>>2017</option> 
            <option value="2018" <?php if($tahun==2018){echo "selected";}?>>2018</option> 
            <option value="2019" <?php if($tahun==2019){echo "selected";}?>>2019</option> 
        </select>
    </div>
     <div class="col s12">
     <button type="submit" name="hitung" class="waves-effect waves-light blue-grey darken-4 btn">LIHAT Perhitungan</button>
     </div>
</form>
<?php 
    if (isset($_POST['k_data'])) { 
    $k_data = $_POST['k_data'];
?> 
<div class="row" style="margin-top:50px;">
    <h4>Hasil K : <?php echo $k_data;?>, Tahun : <?php echo $tahun;?></h4>
    <div class="col s12 m8 l11">
    <table class="responsive-table" id="tab">
        <thead class="blue-grey darken-4 white-text">
            <tr>
             <th class="center">No</th> 
             <th class="center">Tahun</th> 
             <th class="center">Cluster 0</th> 
             <th class="center">Cluster 1</th>  
             <?php if($k_data==3 || $k_data==5){?>
             <th class="center">Cluster 2</th>
             <?php } if($k_data==5){ ?>
             <th class="center">Cluster 3</th>
             <th class="center">Cluster 4</th>   
             <?php } ?>
            </tr>
        </thead>
        <tbody>
        <?php
          $k = "K".$k_data; 
          $sql = "SELECT * From cluster where k_jenis='$k' and tahun='$tahun'";
          $t = mysqli_query($conn,$sql);
          $no = 1;
          while ($data = mysqli_fetch_array($t)) {
        ?>
            <tr class="center">
                <td><?= $no++ ?></td> 
                <td><?= $data['tahun'] ?></td>
                <td><?= $data['cluster0'] ?></td>
                <td><?= $data['cluster1'] ?></td>
                <td><?= $data['cluster2'] ?></td>
                <td><?= $data['cluster3'] ?></td>
                <td><?= $data['cluster4'] ?></td> 
              </td>
            </tr> 
            <?php } ?>
        </tbody>
    </table> 
    </div>
   </div>
<?php } ?>
</div> 
</div>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function(){
        $('select').formSelect();
    });
    $(document).ready(function() {
        $('#tab').DataTable({
            "searching": true
        }); 
    });
</script>