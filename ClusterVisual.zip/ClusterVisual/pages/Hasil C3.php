<?php
    include "koneksi.php";
    
    $tahun = 2015;
    $array = [];
    if(isset($_POST['tahun']))
    {
        $tahun = $_POST['tahun'];
    }
    $sql = "SELECT * From cluster_map inner join provinsi on cluster_map.provinsi = provinsi.nama where cluster_map.tahun='$tahun'";
    $t = mysqli_query($conn,$sql);
    while ($data = mysqli_fetch_array($t)) {
        $array[] = "['".$data["id_map"] ."','".$data["total"]. "']";
    } 
?>
    <h4>Clustering Penyakit Malaria Di Indonesia Tahun <?php echo $tahun;?></h4> 
    <form action="" method="POST">
        <h5>Tahun Perbandingan</h5>
        <div class="row">
            <div class="col s5 m5"> 
                <select name="tahun" required="true">
                    <option value="" disabled>Pilih Tahun</option> 
                    <option value="2015" <?php if($tahun==2015){echo "selected";}?>>2015</option> 
                    <option value="2016" <?php if($tahun==2016){echo "selected";}?>>2016</option> 
                    <option value="2017" <?php if($tahun==2017){echo "selected";}?>>2017</option> 
                    <option value="2018" <?php if($tahun==2018){echo "selected";}?>>2018</option> 
                    <option value="2019" <?php if($tahun==2019){echo "selected";}?>>2019</option> 
                </select>
        </div> 
        </div>
        <div>
        <button class="btn waves-effect teal darken-4 pill" type="submit" name="action">Tampilkan
            <i class="material-icons right">search</i>
        </button>
    </form>
    <div id="container"></div>  
</div>

<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
<script>
$(document).ready(function(){
    $('select').formSelect();
  });
$(document).ready(function(){
    $('.modal').modal();
  });
$('.tooltipped').tooltip();
$('#tab1').DataTable();
</script>

<script src="https://code.highcharts.com/maps/highmaps.js"></script>
<script src="https://code.highcharts.com/maps/modules/exporting.js"></script>
<script src="https://code.highcharts.com/mapdata/countries/id/id-all.js"></script>

<script type="text/javascript">
    // Prepare demo data
// Data is joined to map using value of 'hc-key' property by default.
// See API docs for 'joinBy' for more info on linking data and map.
var data = [<?php echo implode(",\n", $array); ?>];

// Create the chart
Highcharts.mapChart('container', {
    chart: {
        map: 'countries/id/id-all'
    },

    title: {
        text: 'Clustering Penyakit Malaria Di Indonesia'
    },

    subtitle: {
        text: 'Source map: <a href="http://code.highcharts.com/mapdata/countries/id/id-all.js">Indonesia</a>'
    },

    mapNavigation: {
        enabled: true,
        buttonOptions: {
            verticalAlign: 'bottom'
        }
    }, 
    colorAxis: {
        min: 0,
        max: 100,
        minColor: '#EFEFFF', // Color for the lowest value
        maxColor: '#ff0000' // Color for the highest value
    },
    series: [{
        data: data,
        name: 'Cluster 1',
        keys: ['hc-key','value'],
        states: {
            hover: {
                color: '#BADA55'
            }
        },
        dataLabels: {
            enabled: true,
            format: '{point.name}'
        }
    }]
});

</script>